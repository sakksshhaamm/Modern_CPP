#ifndef TYPE_H
#define TYPE_H

enum class Vehicle_Type 
{
    SUV,
    SEDAN,
    ELECTRIC_SUV,
    ICE_TWO_WHEELER,
    ELECTRIC_TWO_WHEELER
};

#endif // TYPE_H
